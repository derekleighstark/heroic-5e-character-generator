const STREET_ANGELS = new Set(["Brightheart", "Ghost Fox", "Hardbody", "Madame Noir", "Nightshade", "Psyche", "Shield Maiden", "Starling"]);
const MIGRATION_VERSION = "merit-flaw-types-1";
const ratingFromName = name => Number(String(name).match(/(?:^|\s)([1-3])(?:\s|\(|$)/)?.[1] ?? 0);

export async function repairStreetAngelsTraits() {
  if (!game.user?.isGM) return;
  for (const actor of game.actors.filter(actor => STREET_ANGELS.has(actor.name))) {
    if (actor.getFlag("heroic5e", "streetAngelsTraitMigration") === MIGRATION_VERSION) continue;
    let markedSection = "";
    const replacements = [], deletes = [], updates = [];
    for (const item of actor.items) {
      const marker = item.name.match(/^(Merits?|Flaws?)\s+/i)?.[1]?.toLowerCase();
      if (marker) markedSection = marker.startsWith("merit") ? "merit" : "flaw";
      if (!["merit", "flaw"].includes(item.type)) continue;
      const desiredType = markedSection || item.type;
      const cleanName = item.name.replace(/^(Merits?|Flaws?)\s+/i, "");
      const cost = Number(item.system.cost) || ratingFromName(cleanName);
      if (desiredType !== item.type) {
        const replacement = item.toObject();
        delete replacement._id;
        replacement.name = cleanName;
        replacement.type = desiredType;
        replacement.system.subtype = desiredType === "merit" ? "Merit" : "Flaw";
        replacement.system.category = desiredType === "merit" ? "Merit" : "Flaw";
        replacement.system.cost = cost;
        replacements.push(replacement);
        deletes.push(item.id);
      } else {
        const update = { _id: item.id };
        if (cleanName !== item.name) update.name = cleanName;
        if (cost !== Number(item.system.cost)) update["system.cost"] = cost;
        if (Object.keys(update).length > 1) updates.push(update);
      }
    }
    if (deletes.length) await actor.deleteEmbeddedDocuments("Item", deletes);
    if (replacements.length) await actor.createEmbeddedDocuments("Item", replacements);
    if (updates.length) await actor.updateEmbeddedDocuments("Item", updates);
    await actor.setFlag("heroic5e", "streetAngelsTraitMigration", MIGRATION_VERSION);
  }
}
